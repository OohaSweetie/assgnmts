package com.cg.springlab.dto;

import java.util.List;

public class Employee implements EmployeeDetail{
     int age;
     int empId;
     String empName;
     double empsal;
     SBU sbuone;
	

 	@Override
	public void getAllEmployeeDetail() {
 		System.out.println("Employee"+"[empAge="+age+","+" empId="+empId+","
	                          +"empName="+empName+","+"empSalary="+empsal+"]");
 		
 		
 		System.out.println("sbu details"+"[sbuCode="+sbuone.getSbuCode()+","
 		                                +" sbuHead="+sbuone.getSbuHead()+","
 		                                +" sbuName="+sbuone.getSbuName()+"]");
	}
     
	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public double getEmpsal() {
		return empsal;
	}


	public void setEmpsal(double empsal) {
		this.empsal = empsal;
	}


	public SBU getSbuone() {
		return sbuone;
	}


	public void setSbuone(SBU sbuone) {
		this.sbuone = sbuone;
	}

	}
